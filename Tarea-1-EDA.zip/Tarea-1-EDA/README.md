# README Tarea1
## Forma de Compilacion:

Dependiendo del Sist. Operativo en el cual se trabaje, se compilara de 2 formas (en nuestro caso Windows y Mac) en la terminal mediante el uso de un makefile.    
La primera forma para compilar en Windows sera mediante el uso del comando *mingw32-make run*. Mientras que para compilar en Mac sera el comando *make run*.

## Ejecutar Tarea

Para la ejecucion del programa no se necesita modificar ninguna parte de el ya que esta todo automatizado.
A la hora de ejecutar la tarea, el mismo programa le pedira al usuario que hacer, por lo que solo hay que seguir las indicaciones de la terminal e ingresar los valores apropiados.

